package si.iskratel.pmon.generator.measurements;

public class TAS extends IMSNodeSimulator {
	
	// TODO
//	SC.AttSessionImOrig
//	SC.SuccSessionImOrig.sum
//	SC.AnsSessionImOrig
//	SC.FailSessionImOrig.sum
//
//	SC.AttSessionAsOrig
//	SC.SuccSessionAsOrig.sum
//	
//	CONF.AttCreation
//	CONF.SuccCreation
//	CONF.AttJoining
//	CONF.SuccJoining
//	CONF.AttInvitation
//	CONF.SuccInviJoinConf.sum
//	CONF.AttSubscription
//	CONF.SuccSubscription
//	CONF.OnlineUserMax
//	CONF.OnlineConfMax
//	CONF.OnlineUserMean
//	CONF.OnlineConfMean
//
//	PRES.OnlineWatcherMax
//	PRES.OnlinePresentityMax
//	PRES.OnlineWatcherMean
//	PRES.OnlinePresentityMean
//	PRES.AttSubscribe
//	PRES.SuccSubscribe.sum
//	PRES.AttNotify
//	PRES.SuccNotify
//	PRES.AttPublish
//	PRES.SuccPub
//	
//	SC.CFUUsed
//	SC.CFBUsed
//	SC.CFNRUsed
//	SC.CFNRcUsed
//	SC.CFNLUsed
//	SC.CDUsed
//	SC.CWUsed
//	SC.HoldUsed
//
//	SC.OCBUsed
//	SC.ICBUsed
//	SC.ACRUsed
//
//	SC.OIPUsed
//	SC.OIRUsed
//
//	SC.TIPUsed
//	SC.TIRUsed
//	SC.MWIUsed
//	SC.FAUsed
//	SC.CRSUsed
//	SC.CATUsed
//
//
//	SC.AOCSUsedOrig
//	SC.AOCSUsedTerm
//	SC.AOCDUsed
//	SC.AOCEUsed
//
//	SC.CCBSUsed
//	SC.CCNRUsed
//	SC.CUGUsed
//	SC.MCIDUsed
//	
//	SC.ECTBlindUsed
//	SC.ECTAskUsed

	
	
	@Override
	public void simulateValues() {
		simulateEmergencySessions();
	}
	
	private void simulateEmergencySessions() {
		
		// TODO
//		SC_AttEmgSess = getNextValue(SC_AttEmgSess, 500, 100);
//		SC_FailEmgSess = getNextValue(SC_FailEmgSess, 60, 10);
//		SC_SuccEmgSess = SC_AttEmgSess - SC_FailEmgSess;
//		SC_SuccEmgSessEstabTimeMean = getNextValue(SC_SuccEmgSessEstabTimeMean, 50, 10);
//		
//		measurementsMap.put("SC.AttEmgSess", SC_AttEmgSess);
//		measurementsMap.put("SC.SuccEmgSess", SC_SuccEmgSess);
//		measurementsMap.put("SC.FailEmgSess", SC_FailEmgSess);
//		measurementsMap.put("SC.SuccEmgSessEstabTimeMean", SC_SuccEmgSessEstabTimeMean);
		
	}
	
	
}
