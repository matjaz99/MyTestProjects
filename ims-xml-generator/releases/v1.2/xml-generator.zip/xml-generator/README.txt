Ideja
Simulator XML datotek z generiranimi meritvami v IMS okolju.

Kratek opis
Aplikacija simulira meritve (števce) na IMS core elementih, ki so potrebne za statistično obdelavo podatkov za 'Performance monitoring'. Z aplikacijo se lahko izvede testiranje funkcionalnosti na produktu MO6011AX, še preden so meritve dejansko podprte na IA, IE in IC produktih, kar močno skrajša razvojni čas na produktu MO6011AX. Prav tako aplikacija omogoča generiranje velike količine datotek za namen performančnega testiranja, hkrati pa ne zahteva postavitve IMS okolja ter izvajanje več tisoč klicev, ki so potrebni za statistično obdelavo.

Dolg opis
Aplikacija generira meritve za IMS produkte: S-CSCF, P-CSCF, I-CSCF, E-CSCF, MGCF, BGCF in TAS. Simulirane vrednosti se generirajo smiselno in niso le skupek naključno generiranih števil, saj bi v tem primeru dobili le beli šum, kar pa ni primerno za statistično obdelavo. Zapis v XML datoteki je skladen s standardi: 3GPP TS 32432 in 3GPP TS 32409.
Simulator je javanska aplikacija, ki jo je enostavno zagnati z ukazom 'java –jar xml-generator.jar' iz ukazne vrstice. Ponuja možnost simuliranja enega ali več IMS elementov hkrati.

Z uporabo simulatorja se izognemo postavitvi virtualiziranega okolja na OpenStack, inštalacijo in konfiguracijo IMS komponent ter izvajanje klicev. Pri tem bi moral biti odstotek klicev nesupešnih (iz različnih vzrokov), kar je težko doseči na testnem okolju.
Ocenjen prihranek: krajši razvojni čas na produktu MO6011AX, nakup 5 strežnikov ter najmanj 3 ČM vložka za vključitev strežnikov v cloud infrastrukturo ter namestitev IMS produktov. Sledi še izvedba testov (nekaj ČM).




Ocenjeni stroški, ki bi nastali brez tega programa so:
nakup serverjev 5 
vključitev in konfiguriranje strežnikov ni potrebno
za nadaljevanje dela na projektu je potrebno vzpostaviti testno okolje v makedoniji na katerem bi izvedli testiranje PO
za to bi potrebovali 5 serverjev + install  konfig
ter izvedbo klicanja. Pri tem bi moral biti odstotek klicev nesupešnih, kar je težko doseči na testnem okolju.
Program omogoča simuliranje neuspešnih klicev iz različnih razlogov, ki jih ni mogoče vedno poustvariti v testnem okolju
za testiranje bi potrebovali osebo, ki bi opravila več tisoč klicev, od katerih bi moral biti odstotek nesupešnih (z različnim razlogom failCause)
