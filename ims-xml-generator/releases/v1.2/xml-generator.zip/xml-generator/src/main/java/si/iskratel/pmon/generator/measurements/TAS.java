package si.iskratel.pmon.generator.measurements;

public class TAS extends IMSNodeSimulator {
	
	private int SC_AttSessionImOrig = 5000;
	private int SC_SuccSessionImOrig = 4000;
	private int SC_AnsSessionImOrig = 3000;
	private int SC_FailSessionImOrig = 1000;

	private int SC_AttSessionAsOrig = 4000;
	private int SC_SuccSessionAsOrig = 3000;
	
	private int CONF_AttCreation = 500;
	private int CONF_SuccCreation = 400;
	private int CONF_AttJoining = 300;
	private int CONF_SuccJoining = 250;
	private int CONF_AttInvitation = 100;
	private int CONF_SuccInviJoinConf = 80;
	private int CONF_AttSubscription = 100;
	private int CONF_SuccSubscription = 80;
	private int CONF_OnlineUserMax = 2000;
	private int CONF_OnlineConfMax = 1000;
	private int CONF_OnlineUserMean = 1500;
	private int CONF_OnlineConfMean = 500;

	private int PRES_OnlineWatcherMax = 1000;
	private int PRES_OnlinePresentityMax = 1000;
	private int PRES_OnlineWatcherMean = 500;
	private int PRES_OnlinePresentityMean = 500;
	private int PRES_AttSubscribe = 500;
	private int PRES_SuccSubscribe = 400;
	private int PRES_AttNotify = 200;
	private int PRES_SuccNotify = 180;
	private int PRES_AttPublish = 200;
	private int PRES_SuccPub = 180;
	
//	SC.CFUUsed
//	SC.CFBUsed
//	SC.CFNRUsed
//	SC.CFNRcUsed
//	SC.CFNLUsed
//	SC.CDUsed
//	SC.CWUsed
//	SC.HoldUsed
//
//	SC.OCBUsed
//	SC.ICBUsed
//	SC.ACRUsed
//
//	SC.OIPUsed
//	SC.OIRUsed
//
//	SC.TIPUsed
//	SC.TIRUsed
//	SC.MWIUsed
//	SC.FAUsed
//	SC.CRSUsed
//	SC.CATUsed
//
//
//	SC.AOCSUsedOrig
//	SC.AOCSUsedTerm
//	SC.AOCDUsed
//	SC.AOCEUsed
//
//	SC.CCBSUsed
//	SC.CCNRUsed
//	SC.CUGUsed
//	SC.MCIDUsed
//	
//	SC.ECTBlindUsed
//	SC.ECTAskUsed

	
	
	@Override
	public void simulateValues() {
		simulateSessionImOrig();
		simulateSessionAsOrig();
		simulateConference();
		simulatePresence();
	}
	
	private void simulateSessionImOrig() {
		
		SC_AttSessionImOrig = getNextValue(SC_AttSessionImOrig, 5000, 100);
		SC_FailSessionImOrig = getNextValue(SC_FailSessionImOrig, 1000, 100);
		SC_SuccSessionImOrig = SC_AttSessionImOrig - SC_FailSessionImOrig;
		SC_AnsSessionImOrig = getNextValue(SC_AnsSessionImOrig, 3000, 100);
		
		measurementsMap.put("SC.AttSessionImOrig", SC_AttSessionImOrig);
		measurementsMap.put("SC.SuccSessionImOrig", SC_SuccSessionImOrig);
		measurementsMap.put("SC.FailSessionImOrig", SC_FailSessionImOrig);
		measurementsMap.put("SC.AnsSessionImOrig", SC_AnsSessionImOrig);
		
	}
	
	private void simulateSessionAsOrig() {
		
		SC_AttSessionAsOrig = getNextValue(SC_AttSessionAsOrig, 5000, 100);
		SC_SuccSessionAsOrig = getNextValue(SC_SuccSessionAsOrig, 4000, 100);
		
		measurementsMap.put("SC.SC_AttSessionAsOrig", SC_AttSessionAsOrig);
		measurementsMap.put("SC.SC_SuccSessionAsOrig", SC_SuccSessionAsOrig);
		
	}
	
	private void simulateConference() {
		
		CONF_AttCreation = getNextValue(CONF_AttCreation, 1000, 100);
		CONF_SuccCreation = getNextValue(CONF_SuccCreation, 500, 100);
		CONF_AttJoining = getNextValue(CONF_AttJoining, 500, 10);
		CONF_SuccJoining = getNextValue(CONF_SuccJoining, 300, 10);
		CONF_AttInvitation = getNextValue(CONF_AttInvitation, 1000, 100);
		CONF_SuccInviJoinConf = getNextValue(CONF_SuccInviJoinConf, 2500, 100);
		CONF_AttSubscription = getNextValue(CONF_AttSubscription, 500, 10);
		CONF_SuccSubscription = getNextValue(CONF_SuccSubscription, 400, 10);
		CONF_OnlineUserMax = getNextValue(CONF_OnlineUserMax, 3000, 100);
		CONF_OnlineConfMax = getNextValue(CONF_OnlineConfMax, 2500, 100);
		CONF_OnlineUserMean = getNextValue(CONF_OnlineUserMean, 2000, 100);
		CONF_OnlineConfMean = getNextValue(CONF_OnlineConfMean, 1500, 100);
		
		measurementsMap.put("CONF.AttCreation", CONF_AttCreation);
		measurementsMap.put("CONF.SuccCreation", CONF_SuccCreation);
		measurementsMap.put("CONF.AttJoining", CONF_AttJoining);
		measurementsMap.put("CONF.SuccJoining", CONF_SuccJoining);
		measurementsMap.put("CONF.AttInvitation", CONF_AttInvitation);
		measurementsMap.put("CONF.SuccInviJoinConf", CONF_SuccInviJoinConf);
		measurementsMap.put("CONF.AttSubscription", CONF_AttSubscription);
		measurementsMap.put("CONF.SuccSubscription", CONF_SuccSubscription);
		measurementsMap.put("CONF.OnlineUserMax", CONF_OnlineUserMax);
		measurementsMap.put("CONF.OnlineConfMax", CONF_OnlineConfMax);
		measurementsMap.put("CONF.OnlineUserMean", CONF_OnlineUserMean);
		measurementsMap.put("CONF.OnlineConfMean", CONF_OnlineConfMean);
		
	}
	
	private void simulatePresence() {
		
		PRES_OnlineWatcherMax = getNextValue(PRES_OnlineWatcherMax, 2000, 50);
		PRES_OnlinePresentityMax = getNextValue(PRES_OnlinePresentityMax, 2000, 50);
		PRES_OnlineWatcherMean = getNextValue(PRES_OnlineWatcherMean, 1000, 50);
		PRES_OnlinePresentityMean = getNextValue(PRES_OnlinePresentityMean, 1000, 50);
		PRES_AttSubscribe = getNextValue(PRES_AttSubscribe, 1000, 50);
		PRES_SuccSubscribe = getNextValue(PRES_SuccSubscribe, 500, 50);
		PRES_AttNotify = getNextValue(PRES_AttNotify, 500, 50);
		PRES_SuccNotify = getNextValue(PRES_SuccNotify, 400, 10);
		PRES_AttPublish = getNextValue(PRES_AttPublish, 300, 50);
		PRES_SuccPub = getNextValue(PRES_SuccPub, 250, 50);
		
		measurementsMap.put("CONF.PRES_OnlineWatcherMax", PRES_OnlineWatcherMax);
		measurementsMap.put("CONF.PRES_OnlinePresentityMax", PRES_OnlinePresentityMax);
		measurementsMap.put("CONF.PRES_OnlineWatcherMean", PRES_OnlineWatcherMean);
		measurementsMap.put("CONF.PRES_OnlinePresentityMean", PRES_OnlinePresentityMean);
		measurementsMap.put("CONF.PRES_AttSubscribe", PRES_AttSubscribe);
		measurementsMap.put("CONF.PRES_SuccSubscribe", PRES_SuccSubscribe);
		measurementsMap.put("CONF.PRES_AttNotify", PRES_AttNotify);
		measurementsMap.put("CONF.PRES_SuccNotify", PRES_SuccNotify);
		measurementsMap.put("CONF.PRES_AttPublish", PRES_AttPublish);
		measurementsMap.put("CONF.PRES_SuccPub", PRES_SuccPub);
		
	}
	
	
}
