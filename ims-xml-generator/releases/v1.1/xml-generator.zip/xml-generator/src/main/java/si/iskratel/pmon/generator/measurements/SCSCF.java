package si.iskratel.pmon.generator.measurements;

public class SCSCF extends IMSNodeSimulator {
	
	private int UR_AttInitReg = 1000;
//	private int UR_SuccInitReg = 900;
	private int UR_FailInitReg = 100;
	
	private int UR_AttReReg = 100;
//	private int UR_SuccReReg = 80;
	private int UR_FailReReg = 20;
	
	private int UR_AttDeRegUe = 200;
//	private int UR_SuccDeRegUe = 150;
	private int UR_FailDeRegUe = 50;
	
	private int UR_AttDeRegHss = 200;
//	private int UR_SuccDeRegHss = 150;
	private int UR_FailDeRegHss = 50;
	
	private int UR_AttDeRegSrvPlatform = 200;
//	private int UR_SuccDeRegSrvPlatform = 150;
	private int UR_FailDeRegSrvPlatform = 50;

	private int UR_Att3rdPartyReg = 200;
//	private int UR_Succ3rdPartyReg = 150;
	private int UR_Fail3rdPartyReg = 50;
	
	private int UR_AttSAR = 500;
//	private int UR_SuccSAA = 400;
	private int UR_FailSAA = 100;
	
	private int SC_AttSessions = 5000;
	private int SC_SuccSessions = 4800;
	private int SC_AnsSessions = 4000;
	private int SC_FailSessions = 200;
	
	private int SC_NbrSimulAnsSessionMax = 5000;
	private int SC_NbrSimulAnsSessionMean = 3000;
	
	private int SC_DroppedSession = 2000;
	
	private int SC_AttSessionTerm = 6000;
	private int SC_SuccSessionTerm = 5000;
	
	private int SC_AnsTrafOrig = 1000000;
	private int SC_AnsTrafTerm = 1000000;
	
	private int SC_RelBeforeRing = 1000;
	private int SC_RelAfterRing = 3000;
	
	private int IC_AttSessionFromOtherNtwkDmn = 5000;
	private int IC_403SessionFromOtherNtwkDmn = 500;
	private int IC_SuccSessionFromOtherNtwkDmn = 4000;
	private int IC_AttSessionToOtherNtwkDmn = 5000;
	private int IC_403SessionToOtherNtwkDmn = 500;
	private int IC_SuccSessionToOtherNtwkDmn = 4000;
	
	private int MA_AttMAR = 1000;
	private int MA_SuccMAA = 900;
	private int MA_FailMAA = 100;

	
	
	@Override
	public void simulateValues() {
		simulateInitReg();
		simulateReReg();
		simulateDeRegUe();
		simulateDeRegHss();
		simulateDeRegSrvPlatform();
		simulate3rdPartyReg();
		simulateSAR();
		simulateSessionEstablishments();
		simulateNbrSimulSessions();
		simulateDroppedSessions();
		simulateSessionTerm();
		simulateAccumulatedSessionTime();
		simulateReleaseBeforeAndAfterRinging();
		simulateSessionsToFromOtherDomains();
		simulateMAR();
	}
	
	private void simulateInitReg() {
		
		UR_AttInitReg = getNextValue(UR_AttInitReg, 1000, 100);
		UR_FailInitReg = getNextValue(UR_FailInitReg, 300, 50);
		
		measurementsMap.put("UR.AttInitReg", UR_AttInitReg);
		measurementsMap.put("UR.SuccInitReg", UR_AttInitReg - UR_FailInitReg);
		measurementsMap.put("UR.FailInitReg", UR_FailInitReg);
		
	}
	
	private void simulateReReg() {
		
		UR_AttReReg = getNextValue(UR_AttReReg, 200, 30);
		UR_FailReReg = getNextValue(UR_FailReReg, 200, 10);
		
		measurementsMap.put("UR.AttReReg", UR_AttReReg);
		measurementsMap.put("UR.SuccReReg", UR_AttReReg - UR_FailReReg);
		measurementsMap.put("UR.FailReReg", UR_FailReReg);
		
	}
	
	private void simulateDeRegUe() {
		
		UR_AttDeRegUe = getNextValue(UR_AttDeRegUe, 200, 30);
		UR_FailDeRegUe = getNextValue(UR_FailDeRegUe, 200, 10);
		
		measurementsMap.put("UR.AttDeRegUe", UR_AttDeRegUe);
		measurementsMap.put("UR.SuccDeRegUe", UR_AttDeRegUe - UR_FailDeRegUe);
		measurementsMap.put("UR.FailDeRegUe", UR_FailDeRegUe);
		
	}
	
	private void simulateDeRegHss() {
		
		UR_AttDeRegHss = getNextValue(UR_AttDeRegHss, 200, 30);
		UR_FailDeRegHss = getNextValue(UR_FailDeRegHss, 200, 10);
		
		measurementsMap.put("UR.AttDeRegHss", UR_AttDeRegHss);
		measurementsMap.put("UR.SuccDeRegHss", UR_AttDeRegHss - UR_FailDeRegHss);
		measurementsMap.put("UR.FailDeRegHss", UR_FailDeRegHss);
		
	}
	
	private void simulateDeRegSrvPlatform() {
		
		UR_AttDeRegSrvPlatform = getNextValue(UR_AttDeRegSrvPlatform, 200, 30);
		UR_FailDeRegSrvPlatform = getNextValue(UR_FailDeRegSrvPlatform, 200, 10);
		
		measurementsMap.put("UR.AttDeRegSrvPlatform", UR_AttDeRegSrvPlatform);
		measurementsMap.put("UR.SuccDeRegSrvPlatform", UR_AttDeRegSrvPlatform - UR_FailDeRegSrvPlatform);
		measurementsMap.put("UR.FailDeRegSrvPlatform", UR_FailDeRegSrvPlatform);
		
	}
	
	private void simulate3rdPartyReg() {
		
		UR_Att3rdPartyReg = getNextValue(UR_Att3rdPartyReg, 200, 30);
		UR_Fail3rdPartyReg = getNextValue(UR_Fail3rdPartyReg, 200, 10);
		
		measurementsMap.put("UR.Att3rdPartyReg", UR_Att3rdPartyReg);
		measurementsMap.put("UR.Succ3rdPartyReg", UR_Att3rdPartyReg - UR_Fail3rdPartyReg);
		measurementsMap.put("UR.Fail3rdPartyReg", UR_Fail3rdPartyReg);
		
	}
	
	private void simulateSAR() {
		
		UR_AttSAR = getNextValue(UR_AttSAR, 1000, 100);
		UR_FailSAA = getNextValue(UR_FailSAA, 300, 50);
		
		measurementsMap.put("UR.AttSAR", UR_AttSAR);
		measurementsMap.put("UR.SuccSAA", UR_AttSAR - UR_FailSAA);
		measurementsMap.put("UR.FailSAA", UR_FailSAA);
		
	}
	
	private void simulateSessionEstablishments() {
		
		SC_AttSessions = getNextValue(SC_AttSessions, 5000, 500);
		SC_FailSessions = getNextValue(SC_FailSessions, 1000, 300);
		SC_SuccSessions = getNextValue(SC_AttSessions - SC_FailSessions, SC_AttSessions, 500);
		SC_AnsSessions = getNextValue(SC_AnsSessions, SC_SuccSessions, 500);
		
		measurementsMap.put("SC.AttSessions", SC_AttSessions);
		measurementsMap.put("SC.SuccSessions", SC_SuccSessions);
		measurementsMap.put("SC.AnsSessions", SC_AnsSessions);
		measurementsMap.put("SC.FailSessions", SC_FailSessions);
		
	}
	
	private void simulateNbrSimulSessions() {
		
		SC_NbrSimulAnsSessionMax = getNextValue(SC_NbrSimulAnsSessionMax, 10000, 2000);
		SC_NbrSimulAnsSessionMean = getNextValue(SC_NbrSimulAnsSessionMean, 7000, 500);
		
		measurementsMap.put("SC.NbrSimulAnsSessionMax", SC_NbrSimulAnsSessionMax);
		measurementsMap.put("SC.NbrSimulAnsSessionMean", SC_NbrSimulAnsSessionMean);
		
	}
	
	private void simulateDroppedSessions() {
		
		SC_DroppedSession = getNextValue(SC_DroppedSession, 3000, 500);
		
		measurementsMap.put("SC.DroppedSession", SC_DroppedSession);
		
	}
	
	private void simulateSessionTerm() {
		
		SC_AttSessionTerm = getNextValue(SC_AttSessionTerm, 6000, 1000);
		SC_SuccSessionTerm = getNextValue(SC_SuccSessionTerm, 5000, 500);
		
		measurementsMap.put("SC.AttSessionTerm", SC_AttSessionTerm);
		measurementsMap.put("SC.SuccSessionTerm", SC_SuccSessionTerm);
		
	}
	
	private void simulateAccumulatedSessionTime() {
		
		SC_AnsTrafOrig = getNextValue(SC_AnsTrafOrig, 1500000, 3000);
		SC_AnsTrafTerm = getNextValue(SC_AnsTrafTerm, 1500000, 3000);
		
		measurementsMap.put("SC.AnsTrafOrig", SC_AnsTrafOrig);
		measurementsMap.put("SC.AnsTrafTerm", SC_AnsTrafTerm);
		
	}
	
	private void simulateReleaseBeforeAndAfterRinging() {
		
		SC_RelBeforeRing = getNextValue(SC_RelBeforeRing, 1500, 100);
		SC_RelAfterRing = getNextValue(SC_AnsTrafTerm, 4000, 100);
		
		measurementsMap.put("SC.RelBeforeRing", SC_RelBeforeRing);
		measurementsMap.put("SC.RelAfterRing", SC_RelAfterRing);
		
	}
	
	private void simulateSessionsToFromOtherDomains() {
		
		IC_AttSessionFromOtherNtwkDmn = getNextValue(IC_AttSessionFromOtherNtwkDmn, 5000, 500);
		IC_403SessionFromOtherNtwkDmn = getNextValue(IC_403SessionFromOtherNtwkDmn, 500, 20);
		IC_SuccSessionFromOtherNtwkDmn = getNextValue(IC_SuccSessionFromOtherNtwkDmn, 4000, 500);
		
		IC_AttSessionToOtherNtwkDmn = getNextValue(IC_AttSessionToOtherNtwkDmn, 5000, 500);
		IC_403SessionToOtherNtwkDmn = getNextValue(IC_403SessionToOtherNtwkDmn, 500, 20);
		IC_SuccSessionToOtherNtwkDmn = getNextValue(IC_SuccSessionToOtherNtwkDmn, 4000, 500);
		
		measurementsMap.put("IC.AttSessionFromOtherNtwkDmn", IC_AttSessionFromOtherNtwkDmn);
		measurementsMap.put("IC.403SessionFromOtherNtwkDmn", IC_403SessionFromOtherNtwkDmn);
		measurementsMap.put("IC.SuccSessionFromOtherNtwkDmn", IC_SuccSessionFromOtherNtwkDmn);
		measurementsMap.put("IC.AttSessionToOtherNtwkDmn", IC_AttSessionToOtherNtwkDmn);
		measurementsMap.put("IC.403SessionToOtherNtwkDmn", IC_403SessionToOtherNtwkDmn);
		measurementsMap.put("IC.SuccSessionToOtherNtwkDmn", IC_SuccSessionToOtherNtwkDmn);
		
	}
	
	private void simulateMAR() {
		
		MA_AttMAR = getNextValue(MA_AttMAR, 1000, 100);
		MA_FailMAA = getNextValue(MA_FailMAA, 300, 50);
		MA_SuccMAA = MA_AttMAR - MA_FailMAA;
		
		measurementsMap.put("MA.AttMAR", MA_AttMAR);
		measurementsMap.put("MA.SuccMAA", MA_SuccMAA);
		measurementsMap.put("MA.FailMAA", MA_FailMAA);
		
	}
	
	
}
